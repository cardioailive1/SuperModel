'use client'

import { useRef } from 'react'
import { DOMAINS, ANALYSIS_MODES, type DomainKey } from '@/lib/domains'
import clsx from 'clsx'

interface AnalysisPanelProps {
  domain: DomainKey
  prompt: string
  onPromptChange: (v: string) => void
  modes: string[]
  onModeToggle: (mode: string) => void
  output: string
  isLoading: boolean
  isStreaming: boolean
  metrics: { [k: string]: string } | null
  onRun: () => void
  onExampleClick: (ex: string) => void
}

function MetricCard({ value, label }: { value: string; label: string }) {
  return (
    <div className="bg-ocean-400/5 border border-ocean-400/15 rounded-lg p-3 text-center">
      <div className="text-xl font-bold font-mono text-ocean-400 mb-0.5" style={{ textShadow: '0 0 14px rgba(0,194,224,0.35)' }}>
        {value}
      </div>
      <div className="text-[10px] text-navy-400 font-mono">{label}</div>
    </div>
  )
}

function CapabilityCard({ name, detail }: { name: string; detail: string }) {
  return (
    <div className="bg-navy-800 border border-ocean-400/12 rounded-lg p-3 hover:border-ocean-400/25 transition-colors">
      <div className="w-6 h-6 rounded bg-ocean-400/10 flex items-center justify-center mb-2">
        <svg viewBox="0 0 24 24" fill="none" stroke="#00c2e0" strokeWidth="1.8" className="w-3 h-3">
          <circle cx="12" cy="12" r="4"/><path d="M12 2v3m0 14v3M2 12h3m14 0h3"/>
        </svg>
      </div>
      <div className="text-xs font-medium text-white mb-0.5">{name}</div>
      <div className="text-[10.5px] text-navy-400 leading-relaxed">{detail}</div>
    </div>
  )
}

export default function AnalysisPanel({
  domain, prompt, onPromptChange, modes, onModeToggle,
  output, isLoading, isStreaming, metrics, onRun, onExampleClick
}: AnalysisPanelProps) {
  const d = DOMAINS[domain]
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  const copyOutput = () => {
    if (output) navigator.clipboard?.writeText(output)
  }

  return (
    <main className="flex-1 overflow-y-auto p-6">
      {/* Domain header */}
      <div className="mb-5">
        <h1 className="text-lg font-semibold text-white mb-1">{d.title}</h1>
        <p className="text-xs text-navy-300 leading-relaxed">{d.description}</p>
      </div>

      {/* Capabilities grid */}
      <div className="grid grid-cols-3 gap-2 mb-5">
        {d.capabilities.map(cap => (
          <CapabilityCard key={cap.name} name={cap.name} detail={cap.detail} />
        ))}
      </div>

      {/* Prompt input */}
      <div className="bg-navy-800 border border-ocean-400/25 rounded-xl p-4 mb-4">
        <div className="text-[9px] font-mono text-navy-400 tracking-[1.5px] uppercase mb-2">
          Engineering Prompt
        </div>
        <textarea
          ref={textareaRef}
          value={prompt}
          onChange={e => onPromptChange(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter' && e.ctrlKey) { e.preventDefault(); onRun() } }}
          placeholder="Describe what you want to design, analyze, or build..."
          rows={3}
          className="w-full bg-transparent border-none outline-none text-[13px] text-white placeholder-navy-500 resize-none leading-relaxed font-sans"
        />
        <div className="flex items-center justify-between mt-3 pt-3 border-t border-ocean-400/10 flex-wrap gap-2">
          {/* Mode chips */}
          <div className="flex gap-1.5 flex-wrap">
            {ANALYSIS_MODES.map(mode => (
              <button
                key={mode}
                onClick={() => onModeToggle(mode)}
                className={clsx(
                  'text-[10.5px] font-mono px-2.5 py-1 rounded-full border transition-all',
                  modes.includes(mode)
                    ? 'bg-ocean-400/12 border-ocean-400/40 text-ocean-300'
                    : 'border-ocean-400/15 text-navy-400 hover:border-ocean-400/30 hover:text-navy-300'
                )}
              >
                {mode}
              </button>
            ))}
          </div>
          {/* Run button */}
          <button
            onClick={onRun}
            disabled={isLoading || !prompt.trim()}
            className="flex items-center gap-2 bg-ocean-500 hover:bg-ocean-400 disabled:opacity-40 disabled:cursor-not-allowed text-white font-semibold text-xs px-5 py-2 rounded-lg transition-all duration-150 shadow-[0_0_20px_rgba(0,154,181,0.3)] hover:shadow-[0_0_28px_rgba(0,194,224,0.45)]"
          >
            <svg viewBox="0 0 24 24" fill="currentColor" className="w-3.5 h-3.5">
              <path d="M8 5v14l11-7z"/>
            </svg>
            {isLoading ? 'Running...' : 'Run SuperModel'}
          </button>
        </div>
      </div>

      {/* Example prompts */}
      <div className="mb-5">
        <div className="text-[9px] font-mono text-navy-500 tracking-[1.5px] uppercase mb-2">
          Example Prompts
        </div>
        <div className="flex flex-col gap-1.5">
          {d.examples.map(ex => (
            <button
              key={ex}
              onClick={() => onExampleClick(ex)}
              className="text-left text-[11.5px] text-navy-300 border border-ocean-400/12 rounded-md px-3 py-2 hover:text-ocean-300 hover:border-ocean-400/35 hover:bg-ocean-400/5 transition-all leading-relaxed"
            >
              {ex}
            </button>
          ))}
        </div>
      </div>

      {/* Output panel */}
      <div className={clsx('bg-navy-800 border rounded-xl p-5', isLoading ? 'scan-line border-ocean-400/25' : 'border-ocean-400/12')}>
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-ocean-400/10">
          <div className="text-[9px] font-mono text-navy-400 tracking-[1.5px] uppercase">
            SuperModel Output
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[9px] font-mono px-1.5 py-0.5 rounded border bg-ocean-400/12 text-ocean-300 border-ocean-400/28">
              {d.badge}
            </span>
            {output && (
              <button
                onClick={copyOutput}
                className="text-[10px] font-mono text-navy-400 hover:text-ocean-300 px-2 py-0.5 border border-ocean-400/15 rounded hover:border-ocean-400/35 transition-all"
              >
                Copy
              </button>
            )}
          </div>
        </div>

        {/* Output body */}
        {isLoading && !output ? (
          <div className="flex items-center gap-2 py-8">
            <div className="flex gap-1">
              {[0,1,2].map(i => (
                <div key={i} className="w-1.5 h-1.5 rounded-full bg-ocean-400 animate-bounce" style={{ animationDelay: `${i * 0.15}s` }}/>
              ))}
            </div>
            <span className="text-[11px] text-navy-400 font-mono">
              Synthesizing across {d.metrics[0]} subsystems...
            </span>
          </div>
        ) : output ? (
          <pre className={clsx(
            'text-[12px] text-navy-200 leading-[1.85] whitespace-pre-wrap font-mono',
            isStreaming && 'streaming'
          )}>
            {output}
          </pre>
        ) : (
          <p className="text-[12px] text-navy-500 italic">
            Select a domain, enter your engineering prompt, and click Run SuperModel.
            SuperModel synthesizes domain-specific physics, standards, and design patterns
            to generate detailed engineering output.
          </p>
        )}

        {/* Metrics */}
        {metrics && !isStreaming && (
          <div className="grid grid-cols-4 gap-2 mt-5 pt-4 border-t border-ocean-400/10">
            <MetricCard value={metrics.subsystems} label="Subsystems" />
            <MetricCard value={metrics.standards} label="Standards" />
            <MetricCard value={metrics.simIters} label="Sim iterations" />
            <MetricCard value={metrics.riskFlags} label="Risk flags" />
          </div>
        )}
      </div>
    </main>
  )
}
