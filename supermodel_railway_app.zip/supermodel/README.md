# SuperModel — Corverxis Technologies
## General Engineering Intelligence Platform

A production-ready full-stack application built for Railway deployment.

---

## Stack

| Layer | Technology |
|---|---|
| Frontend | Next.js 14, TypeScript, Tailwind CSS |
| Backend | FastAPI (Python 3.11) |
| AI | Anthropic Claude API (claude-sonnet-4-6) |
| Database | PostgreSQL (Railway managed) |
| Cache | Redis (Railway managed) |
| Hosting | Railway (both services) |

---

## Project Structure

```
supermodel/
├── frontend/          # Next.js app
│   ├── app/           # App router pages
│   ├── components/    # React components
│   └── lib/           # Utilities
├── backend/           # FastAPI server
│   ├── main.py        # Entry point
│   ├── routers/       # API route handlers
│   └── prompts/       # Domain system prompts
├── railway.toml       # Railway multi-service config
└── README.md
```

---

## Railway Deployment

### One-click deploy

1. Push this repo to GitHub
2. Go to railway.app → New Project → Deploy from GitHub
3. Railway auto-detects both services from `railway.toml`
4. Add environment variables (see below)
5. Deploy

### Environment Variables

**Backend service:**
```
ANTHROPIC_API_KEY=your_key_here
DATABASE_URL=${{Postgres.DATABASE_URL}}
REDIS_URL=${{Redis.REDIS_URL}}
CORS_ORIGINS=https://your-frontend.railway.app
SECRET_KEY=generate-a-random-secret
```

**Frontend service:**
```
NEXT_PUBLIC_API_URL=https://your-backend.railway.app
NEXT_PUBLIC_APP_NAME=SuperModel
```

---

## Local Development

```bash
# Backend
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000

# Frontend
cd frontend
npm install
npm run dev
```

---

## Domains Supported (15)

Aerospace, Electric Vehicles, Electronics & EDA, Sensor Technology,
Sensor Prediction, Power Systems, Industrial Automation, Manufacturing,
Healthcare Devices, Materials Science, Robotics, Renewable Energy,
Defense Systems, Software Engineering, Graphic Design

---

*Corverxis Technologies — AI Engineering & Consulting*
