/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{js,ts,jsx,tsx}',
    './components/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        navy: {
          50:  '#e8f0f8',
          100: '#c5d4e8',
          200: '#9cb4d4',
          300: '#6d90bc',
          400: '#4a76a8',
          500: '#2a5d95',
          600: '#1a3560',
          700: '#112845',
          800: '#0e2444',
          900: '#0b1f3a',
          950: '#07111f',
        },
        ocean: {
          50:  '#e0f9ff',
          100: '#b3f0ff',
          200: '#7de5f4',
          300: '#48cae4',
          400: '#00c2e0',
          500: '#009ab5',
          600: '#007a91',
          700: '#005f73',
          800: '#003d4d',
          900: '#001f26',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'scan': 'scan 1.5s linear infinite',
        'fade-in': 'fadeIn 0.3s ease',
        'slide-up': 'slideUp 0.3s ease',
      },
      keyframes: {
        scan: {
          '0%': { transform: 'translateX(-100%)' },
          '100%': { transform: 'translateX(200%)' },
        },
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(8px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
      },
    },
  },
  plugins: [],
}
