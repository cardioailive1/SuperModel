"""
Analysis router — streams Claude responses for all 15 engineering domains.
Each domain has a specialized system prompt that shapes Claude into a
domain expert with standards knowledge and structured output format.
"""

import os
import json
import uuid
from typing import AsyncGenerator
from fastapi import APIRouter, Request, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from prompts.domain_prompts import DOMAIN_PROMPTS, DOMAIN_CONFIG

router = APIRouter()


class AnalyzeRequest(BaseModel):
    domain: str
    prompt: str
    modes: list[str] = ["Design"]
    session_id: str = ""


class AnalyzeResponse(BaseModel):
    text: str
    domain: str
    session_id: str


# ── Streaming analysis endpoint ───────────────────────────────────────────────
@router.post("/analyze/stream")
async def analyze_stream(req: AnalyzeRequest, request: Request):
    """Stream a Claude engineering analysis response."""

    if req.domain not in DOMAIN_PROMPTS:
        raise HTTPException(status_code=400, detail=f"Unknown domain: {req.domain}")

    client = request.app.state.anthropic
    system_prompt = DOMAIN_PROMPTS[req.domain]
    modes_str = ", ".join(req.modes) if req.modes else "Design"

    user_message = f"""Analysis modes requested: {modes_str}

Engineering request:
{req.prompt}

Provide a detailed, structured engineering analysis with:
- Specific component recommendations and part numbers
- Quantitative values with units
- Applicable standards references
- Risk flags and open items"""

    async def generate() -> AsyncGenerator[str, None]:
        try:
            with client.messages.stream(
                model="claude-sonnet-4-6",
                max_tokens=2048,
                system=system_prompt,
                messages=[{"role": "user", "content": user_message}],
            ) as stream:
                for text in stream.text_stream:
                    # Send as SSE (Server-Sent Events)
                    yield f"data: {json.dumps({'text': text})}\n\n"

            yield f"data: {json.dumps({'done': True})}\n\n"

        except Exception as e:
            yield f"data: {json.dumps({'error': str(e)})}\n\n"

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


# ── Non-streaming fallback ────────────────────────────────────────────────────
@router.post("/analyze")
async def analyze(req: AnalyzeRequest, request: Request):
    """Non-streaming analysis for simpler clients."""

    if req.domain not in DOMAIN_PROMPTS:
        raise HTTPException(status_code=400, detail=f"Unknown domain: {req.domain}")

    client = request.app.state.anthropic
    system_prompt = DOMAIN_PROMPTS[req.domain]
    modes_str = ", ".join(req.modes) if req.modes else "Design"

    user_message = f"""Analysis modes: {modes_str}

{req.prompt}"""

    try:
        message = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=2048,
            system=system_prompt,
            messages=[{"role": "user", "content": user_message}],
        )
        return {
            "text": message.content[0].text,
            "domain": req.domain,
            "session_id": req.session_id or str(uuid.uuid4()),
            "input_tokens": message.usage.input_tokens,
            "output_tokens": message.usage.output_tokens,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── Domain list ───────────────────────────────────────────────────────────────
@router.get("/domains")
async def get_domains():
    """Return all available domains and their configuration."""
    return {
        "domains": [
            {
                "key": key,
                "title": cfg["title"],
                "badge": cfg["badge"],
                "description": cfg["description"],
                "capabilities": cfg["capabilities"],
                "examples": cfg["examples"],
            }
            for key, cfg in DOMAIN_CONFIG.items()
        ]
    }


# ── Chat endpoint ─────────────────────────────────────────────────────────────
class ChatRequest(BaseModel):
    message: str
    domain: str = "general"
    history: list[dict] = []


@router.post("/chat")
async def chat(req: ChatRequest, request: Request):
    """Domain-aware chat assistant."""
    client = request.app.state.anthropic

    system = f"""You are SuperModel, Corverxis Technologies' General Engineering Intelligence platform.
You are an expert across 15 engineering domains: Aerospace, Electric Vehicles, Electronics, 
Sensor Technology, Sensor Prediction, Power Systems, Industrial Automation, Manufacturing,
Healthcare Devices, Materials Science, Robotics, Renewable Energy, Defense Systems, 
Software Engineering, and Graphic Design.

Current active domain: {DOMAIN_CONFIG.get(req.domain, {}).get('title', 'General Engineering')}

Be concise, technically precise, and helpful. Reference real standards and component families.
Keep responses under 200 words for chat — suggest using the main analysis for deep dives."""

    messages = req.history[-6:] + [{"role": "user", "content": req.message}]

    try:
        message = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=400,
            system=system,
            messages=messages,
        )
        return {"reply": message.content[0].text}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
