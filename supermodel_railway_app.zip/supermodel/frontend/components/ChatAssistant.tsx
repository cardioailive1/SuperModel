'use client'

import { useState, useRef, useEffect } from 'react'
import { type DomainKey, DOMAINS } from '@/lib/domains'

interface Message { role: 'user' | 'ai'; text: string }

interface ChatProps { activeDomain: DomainKey }

export default function ChatAssistant({ activeDomain }: ChatProps) {
  const [open, setOpen] = useState(false)
  const [input, setInput] = useState('')
  const [messages, setMessages] = useState<Message[]>([
    { role: 'ai', text: 'Hello! I am SuperModel by Corverxis Technologies. Ask me anything across 15 engineering domains.' }
  ])
  const [loading, setLoading] = useState(false)
  const bottomRef = useRef<HTMLDivElement>(null)
  const history = useRef<{ role: string; content: string }[]>([])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const send = async () => {
    const text = input.trim()
    if (!text || loading) return
    setInput('')
    setMessages(prev => [...prev, { role: 'user', text }])
    setLoading(true)
    history.current.push({ role: 'user', content: text })

    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000'

    try {
      const res = await fetch(`${apiUrl}/api/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          domain: activeDomain,
          history: history.current.slice(-6),
        }),
      })
      const data = await res.json()
      const reply = data.reply || 'Sorry, I could not connect to the SuperModel API.'
      history.current.push({ role: 'assistant', content: reply })
      setMessages(prev => [...prev, { role: 'ai', text: reply }])
    } catch {
      setMessages(prev => [...prev, { role: 'ai', text: 'Connection error. Make sure the backend is running.' }])
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      {/* FAB */}
      <button
        onClick={() => setOpen(o => !o)}
        className="fixed bottom-6 right-6 w-13 h-13 bg-ocean-500 hover:bg-ocean-400 rounded-full flex items-center justify-center shadow-[0_0_24px_rgba(0,194,224,0.4)] transition-all duration-200 hover:scale-110 z-50"
        style={{ width: 52, height: 52 }}
        aria-label="Open chat"
      >
        <svg viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" className="w-5 h-5">
          <path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>
        </svg>
      </button>

      {/* Panel */}
      {open && (
        <div className="fixed bottom-20 right-6 w-80 h-[440px] bg-navy-800 border border-ocean-400/25 rounded-2xl flex flex-col z-50 shadow-2xl animate-slide-up overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 bg-navy-900 border-b border-ocean-400/15">
            <div>
              <div className="text-[13px] font-semibold text-white">SuperModel Assistant</div>
              <div className="text-[10px] text-ocean-400 font-mono">{DOMAINS[activeDomain].title}</div>
            </div>
            <button onClick={() => setOpen(false)} className="text-navy-400 hover:text-white text-lg leading-none">
              x
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-3 flex flex-col gap-2">
            {messages.map((m, i) => (
              <div key={i} className={`max-w-[85%] px-3 py-2 rounded-xl text-xs leading-relaxed ${
                m.role === 'user'
                  ? 'self-end bg-ocean-500 text-white rounded-br-sm'
                  : 'self-start bg-navy-700 text-navy-200 border border-ocean-400/12 rounded-bl-sm'
              }`}>
                {m.text}
              </div>
            ))}
            {loading && (
              <div className="self-start bg-navy-700 border border-ocean-400/12 rounded-xl rounded-bl-sm px-3 py-2">
                <div className="flex gap-1">
                  {[0,1,2].map(i => (
                    <div key={i} className="w-1.5 h-1.5 rounded-full bg-ocean-400 animate-bounce" style={{ animationDelay: `${i*0.15}s` }}/>
                  ))}
                </div>
              </div>
            )}
            <div ref={bottomRef}/>
          </div>

          {/* Input */}
          <div className="p-3 border-t border-ocean-400/15 flex gap-2">
            <textarea
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() } }}
              placeholder="Ask an engineering question..."
              rows={1}
              className="flex-1 bg-navy-700 border border-ocean-400/20 rounded-lg px-3 py-2 text-xs text-white placeholder-navy-500 outline-none resize-none font-sans"
            />
            <button
              onClick={send}
              disabled={loading || !input.trim()}
              className="bg-ocean-500 hover:bg-ocean-400 disabled:opacity-40 text-white text-xs font-semibold px-3 rounded-lg transition-colors whitespace-nowrap"
            >
              Send
            </button>
          </div>
        </div>
      )}
    </>
  )
}
