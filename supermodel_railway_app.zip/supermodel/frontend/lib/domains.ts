export type DomainKey =
  | 'aerospace' | 'ev' | 'elec' | 'sensors' | 'sensorpred'
  | 'power' | 'auto' | 'mfg' | 'health' | 'mat'
  | 'rob' | 'energy' | 'def' | 'software' | 'graphic'

export interface Domain {
  title: string
  badge: string
  description: string
  capabilities: { name: string; detail: string }[]
  examples: string[]
  metrics: [string, string, string, string]
}

export const DOMAINS: Record<DomainKey, Domain> = {
  aerospace: {
    title: 'Aerospace & Space Systems',
    badge: 'Aerospace',
    description: 'Design, simulate, and validate spacecraft, launch vehicles, orbital mechanics, propulsion, avionics, and ground systems',
    capabilities: [
      { name: 'Propulsion design', detail: 'Chemical, electric, nuclear - thrust, Isp, mass flow' },
      { name: 'Orbital mechanics', detail: 'Delta-v budgets, transfer orbits, stationkeeping' },
      { name: 'Avionics & GNC', detail: 'Flight computers, sensor fusion, attitude control' },
      { name: 'Thermal analysis', detail: 'Radiation, MLI blankets, heat pipes, radiators' },
      { name: 'Structural FEA', detail: 'Launch loads, fatigue life, material trade-space' },
      { name: 'Link budgets', detail: 'RF communications, antenna design, ground coverage' },
    ],
    examples: [
      'Design a 6U CubeSat for Earth observation with 2-year LEO lifetime',
      'Compute delta-v budget for a lunar transfer orbit with 500kg payload',
      'Size a bipropellant thruster for 50N thrust at 300s specific impulse',
    ],
    metrics: ['18', '34', '2.4k', '3'],
  },
  ev: {
    title: 'Electric Vehicle Systems',
    badge: 'EV',
    description: 'Full-stack EV design: battery packs, powertrains, BMS, thermal management, and software-defined vehicle architecture',
    capabilities: [
      { name: 'Battery pack design', detail: 'Cell selection, P/S config, energy density' },
      { name: 'Powertrain sizing', detail: 'Motor types, inverter topology, efficiency maps' },
      { name: 'BMS architecture', detail: 'Cell balancing, SOC/SOH estimation, contactor logic' },
      { name: 'Thermal management', detail: 'Liquid cooling loops, heat pump HVAC' },
      { name: 'ADAS & autonomy', detail: 'Sensor fusion, path planning, ISO 26262' },
      { name: 'Charging systems', detail: 'AC/DC onboard charger, V2G, CCS protocols' },
    ],
    examples: [
      'Design a 100kWh NMC battery pack for a 500km range sedan',
      'Size a PMSM motor for 300kW peak power in a performance EV',
      'Create a BMS state machine with full fault handling for a 400V pack',
    ],
    metrics: ['22', '41', '8.1k', '5'],
  },
  elec: {
    title: 'Electronics & EDA',
    badge: 'Electronics',
    description: 'Schematic capture, PCB layout, signal integrity, power electronics, EMC compliance, and firmware generation',
    capabilities: [
      { name: 'Schematic design', detail: 'Component selection, protection circuits, topology' },
      { name: 'PCB layout', detail: 'Stackup design, impedance control, placement rules' },
      { name: 'Signal integrity', detail: 'Eye diagrams, crosstalk, termination strategies' },
      { name: 'Power electronics', detail: 'Buck/boost/flyback, gate drivers, EMI filters' },
      { name: 'RF & EMC', detail: 'Antenna design, shielding, FCC/CE pre-compliance' },
      { name: 'Firmware generation', detail: 'HAL drivers, RTOS config, peripheral init' },
    ],
    examples: [
      'Design a 48V to 5V 10A synchronous buck converter with <1% ripple',
      'Generate STM32H7 firmware for a 6-axis IMU over SPI at 8kHz',
      'Specify a PCB stackup for 10Gbps differential pairs at 85 Ohm impedance',
    ],
    metrics: ['14', '28', '5.2k', '2'],
  },
  sensors: {
    title: 'Sensor Technology',
    badge: 'Sensors',
    description: 'MEMS, optical, chemical sensor design, signal conditioning, calibration, and fusion algorithms',
    capabilities: [
      { name: 'LIDAR & radar', detail: 'ToF, FMCW, point cloud, detection algorithms' },
      { name: 'Machine vision', detail: 'Camera selection, optics sizing, ISP pipeline' },
      { name: 'MEMS sensors', detail: 'Accelerometers, gyros, pressure, microphone design' },
      { name: 'Chemical sensors', detail: 'Gas sensing, electrochemical cells, biosensors' },
      { name: 'Signal conditioning', detail: 'Amps, filters, ADC selection, noise budgets' },
      { name: 'Sensor fusion', detail: 'Kalman filters, complementary, IMU integration' },
    ],
    examples: [
      'Design a 4D imaging radar front-end for automotive ADAS at 77GHz',
      'Size an NDIR CO2 sensor for 0-5000ppm with +-10ppm accuracy',
      'Build an Extended Kalman Filter fusing GPS, IMU, and wheel odometry',
    ],
    metrics: ['11', '22', '3.8k', '1'],
  },
  sensorpred: {
    title: 'Sensor Prediction & Prognostics',
    badge: 'SensorAI',
    description: 'AI-driven predictive maintenance, anomaly detection, RUL estimation, and digital twin integration',
    capabilities: [
      { name: 'Predictive maintenance', detail: 'RUL estimation, failure mode prediction, CBM' },
      { name: 'Anomaly detection', detail: 'Statistical process control, ML-based outlier detection' },
      { name: 'Digital twin sync', detail: 'Physics-informed models, real-time state estimation' },
      { name: 'Time-series ML', detail: 'LSTM, Transformer, TCN for sensor forecasting' },
      { name: 'Sensor health monitoring', detail: 'Drift detection, calibration drift, bias estimation' },
      { name: 'Multi-sensor fusion', detail: 'Bayesian networks, ensemble prediction, confidence' },
    ],
    examples: [
      'Predict remaining useful life of a turbine bearing using vibration and temperature data',
      'Build an LSTM anomaly detection model for a 48-sensor industrial compressor array',
      'Design a real-time predictive maintenance pipeline for a fleet of 500 electric motors',
    ],
    metrics: ['22', '31', '14.7k', '5'],
  },
  power: {
    title: 'Power Systems',
    badge: 'Power',
    description: 'Grid architecture, substations, protection systems, microgrids, energy storage, and power quality',
    capabilities: [
      { name: 'Grid architecture', detail: 'Transmission, distribution, load flow analysis' },
      { name: 'Substation design', detail: 'Transformers, switchgear, protection relays' },
      { name: 'Energy storage', detail: 'BESS sizing, flywheel, pumped hydro integration' },
      { name: 'Microgrids', detail: 'Islanding, droop control, grid-forming inverters' },
      { name: 'Protection systems', detail: 'Relay coordination, arc flash, fault current' },
      { name: 'Power quality', detail: 'Harmonics, flicker, reactive power compensation' },
    ],
    examples: [
      'Design a 50MW grid-connected solar farm with BESS and microgrid islanding',
      'Size protection relays for a 33kV industrial distribution network',
      'Model a 10kVA UPS with double-conversion topology for a data center',
    ],
    metrics: ['16', '38', '4.5k', '4'],
  },
  auto: {
    title: 'Industrial Automation',
    badge: 'Automation',
    description: 'PLC/SCADA systems, motion control, IEC 61131 programming, OPC-UA, and functional safety',
    capabilities: [
      { name: 'PLC programming', detail: 'Ladder logic, ST, FBD - IEC 61131-3 compliant' },
      { name: 'SCADA & HMI', detail: 'Tag databases, alarm management, historian' },
      { name: 'Motion control', detail: 'Servo sizing, cam profiles, electronic gearing' },
      { name: 'Industrial networks', detail: 'PROFINET, EtherCAT, Modbus, OPC-UA' },
      { name: 'PID & advanced control', detail: 'Loop tuning, cascade, model predictive control' },
      { name: 'Functional safety', detail: 'SIL assessment, safety PLCs, IEC 62061' },
    ],
    examples: [
      'Program a PLC-based bottling line with 12 servo axes and vision reject',
      'Design a PID cascade loop for a distillation column temperature profile',
      'Create an OPC-UA information model for a CNC machining cell',
    ],
    metrics: ['20', '45', '6.7k', '3'],
  },
  mfg: {
    title: 'Manufacturing Engineering',
    badge: 'Manufacturing',
    description: 'Process planning, DFM, tolerance analysis, tooling design, lean/six-sigma, and digital twins',
    capabilities: [
      { name: 'Process planning', detail: 'Machining sequences, cycle time, fixturing' },
      { name: 'DFM / DFA', detail: 'Design for manufacture and assembly analysis' },
      { name: 'Tolerance analysis', detail: 'GD&T, worst-case and RSS stack-up' },
      { name: 'Tooling design', detail: 'Injection molds, stamping dies, jigs and fixtures' },
      { name: 'Lean & six sigma', detail: 'VSM, FMEA, SPC, capability studies' },
      { name: 'Digital twin', detail: 'Process simulation, OEE optimization' },
    ],
    examples: [
      'Perform a 3D tolerance stack-up on an automotive door hinge assembly',
      'Design a family mold for 4 plastic enclosure parts in ABS',
      'Create a value stream map and identify bottlenecks in a PCB assembly line',
    ],
    metrics: ['19', '31', '7.2k', '6'],
  },
  health: {
    title: 'Healthcare Device Engineering',
    badge: 'MedTech',
    description: 'FDA/MDR-compliant device design, biocompatibility, risk management, and SaMD development',
    capabilities: [
      { name: 'Bioinstrumentation', detail: 'ECG, EEG, EMG front-ends, AFE design' },
      { name: 'Drug delivery', detail: 'Infusion pumps, auto-injectors, inhalers' },
      { name: 'Imaging systems', detail: 'Ultrasound, CT reconstruction, MRI gradients' },
      { name: 'Regulatory compliance', detail: 'IEC 60601, ISO 13485, 510(k) pathway' },
      { name: 'Wearables & implants', detail: 'Power harvesting, wireless telemetry, biocompat' },
      { name: 'SaMD development', detail: 'IEC 62304, SOUP management, cybersecurity' },
    ],
    examples: [
      'Design a Class II wearable cardiac monitor with 14-day battery life',
      'Create an ISO 14971 risk analysis for a hospital infusion pump',
      'Specify an analog front-end for a 12-lead ECG with 150Hz bandwidth',
    ],
    metrics: ['13', '52', '2.9k', '7'],
  },
  mat: {
    title: 'Materials Science',
    badge: 'Materials',
    description: 'Material selection, composites, failure analysis, coatings, additive manufacturing, and computational materials',
    capabilities: [
      { name: 'Material selection', detail: 'Ashby charts, CES-style trade-space reasoning' },
      { name: 'Composites design', detail: 'Laminate theory, fiber orientation, damage tolerance' },
      { name: 'Failure analysis', detail: 'Fatigue, fracture mechanics, Paris law' },
      { name: 'Surface engineering', detail: 'Coatings, anodizing, PVD/CVD selection' },
      { name: 'Additive manufacturing', detail: 'Design for AM, support strategies' },
      { name: 'Computational', detail: 'DFT, molecular dynamics, CALPHAD phase diagrams' },
    ],
    examples: [
      'Select material for a 200C rotating shaft with fatigue limit >500MPa',
      'Design a CFRP pressure vessel laminate for 350 bar service at 80C',
      'Analyze fatigue crack growth in 7075-T6 using Paris law parameters',
    ],
    metrics: ['9', '27', '11k', '2'],
  },
  rob: {
    title: 'Robotics Engineering',
    badge: 'Robotics',
    description: 'Kinematics, actuator selection, ROS2 architecture, perception, and motion planning',
    capabilities: [
      { name: 'Kinematics & dynamics', detail: 'FK/IK solvers, Jacobians, Newton-Euler' },
      { name: 'Actuator design', detail: 'Motor sizing, gearbox selection, backdrivability' },
      { name: 'ROS2 architecture', detail: 'Node graph, message types, real-time control' },
      { name: 'Perception', detail: 'SLAM, object detection, 3D scene understanding' },
      { name: 'Motion planning', detail: 'MoveIt2, CHOMP, trajectory optimization' },
      { name: 'Grippers & end-effectors', detail: 'Grasping analysis, soft robotics, tool changers' },
    ],
    examples: [
      'Design a 6-DOF industrial arm with 10kg payload and +-0.05mm repeatability',
      'Generate ROS2 nodes for a mobile manipulation pick-and-place task',
      'Size actuators for a quadruped robot with 20kg body mass at 2 m/s trot',
    ],
    metrics: ['15', '33', '5.9k', '2'],
  },
  energy: {
    title: 'Renewable Energy Systems',
    badge: 'Energy',
    description: 'Solar, wind, hydro, and hydrogen systems: resource assessment, power conversion, and storage',
    capabilities: [
      { name: 'Solar PV design', detail: 'String sizing, inverter selection, yield modeling' },
      { name: 'Wind energy', detail: 'Turbine selection, wake modeling, AEP calculations' },
      { name: 'Hydro & tidal', detail: 'Turbine type selection, civil works, resource assessment' },
      { name: 'Green hydrogen', detail: 'Electrolyzer sizing, seasonal storage, fuel cells' },
      { name: 'Grid-scale storage', detail: 'BESS chemistry, degradation, revenue stacking' },
      { name: 'Energy yield analysis', detail: 'P50/P90 analysis, curtailment, resource data' },
    ],
    examples: [
      'Design a 200MW offshore wind farm with 15MW turbines and HVDC export',
      'Model a green hydrogen plant powered by 100MW solar with seasonal storage',
      'Optimize a hybrid solar+BESS microgrid for an off-grid mining operation',
    ],
    metrics: ['17', '29', '3.3k', '3'],
  },
  def: {
    title: 'Defense Systems',
    badge: 'Defense',
    description: 'Radar, communications, survivability, EW, and mission systems architecture',
    capabilities: [
      { name: 'Radar systems', detail: 'AESA design, waveforms, detection performance' },
      { name: 'Survivability', detail: 'RCS signatures, armor, electronic countermeasures' },
      { name: 'SATCOM & datalinks', detail: 'Link margins, LPI/LPD, anti-jam' },
      { name: 'Mission computing', detail: 'DO-178C software, avionics bus, OpenVPX' },
      { name: 'Cybersecurity', detail: 'NIST RMF, MIL-STD-882, supply chain risk' },
      { name: 'Systems engineering', detail: 'MBSE, SysML, DOORS requirements' },
    ],
    examples: [
      'Architect an AESA radar front-end for airborne fire control at X-band',
      'Design a jam-resistant SATCOM terminal with LPI waveforms and 2W EIRP',
      'Create a DO-178C software plan for a flight management system (DAL A)',
    ],
    metrics: ['24', '67', '4.1k', '8'],
  },
  software: {
    title: 'Software Engineering',
    badge: 'Software',
    description: 'Cloud-native architecture, DevSecOps, embedded systems, AI/ML platforms, and APIs',
    capabilities: [
      { name: 'System architecture', detail: 'Microservices, event-driven, CQRS, DDD' },
      { name: 'Cloud & DevSecOps', detail: 'Kubernetes, Terraform, CI/CD, GitOps, SRE' },
      { name: 'Embedded & RTOS', detail: 'Bare-metal C/C++, FreeRTOS, Zephyr, safety-critical' },
      { name: 'AI/ML engineering', detail: 'Model training pipelines, MLOps, inference' },
      { name: 'Data & APIs', detail: 'REST, GraphQL, gRPC, event streaming, data lakes' },
      { name: 'Security & compliance', detail: 'SAST/DAST, threat modeling, NIST, SOC 2' },
    ],
    examples: [
      'Design a cloud-native microservices architecture for a real-time IoT fleet platform',
      'Architect an MLOps pipeline for continuous training of predictive maintenance models',
      'Build a safety-critical embedded software architecture for IEC 62304 Class C device',
    ],
    metrics: ['24', '38', '9.1k', '4'],
  },
  graphic: {
    title: 'Graphic Design & Visual Systems',
    badge: 'Design',
    description: 'Brand identity, UI/UX design systems, motion graphics, 3D visualization, and technical illustration',
    capabilities: [
      { name: 'Brand identity', detail: 'Logo systems, typography, color theory, guidelines' },
      { name: 'UI/UX design', detail: 'Design systems, wireframing, prototyping, user research' },
      { name: 'Motion graphics', detail: 'Animation, explainer videos, kinetic typography' },
      { name: '3D visualization', detail: 'Product renders, CAD visualization, materials' },
      { name: 'Technical illustration', detail: 'Engineering diagrams, exploded views, infographics' },
      { name: 'Print & digital', detail: 'Packaging, pitch decks, marketing collateral' },
    ],
    examples: [
      'Create a complete brand identity system for a deep-tech aerospace startup',
      'Design a UI component library and design system for an industrial IoT dashboard',
      'Develop a 3D product visualization for a medical device launch',
    ],
    metrics: ['18', '12', '3.2k', '2'],
  },
}

export const DOMAIN_KEYS = Object.keys(DOMAINS) as DomainKey[]

export const ANALYSIS_MODES = ['Design', 'Simulate', 'Optimize', 'Code gen', 'BOM', 'Safety audit', 'Standards']
