"""
Domain system prompts and configuration for all 15 SuperModel engineering domains.
Each system prompt shapes Claude into a specialized domain expert.
"""

# ── Domain Configuration (titles, badges, caps, examples) ────────────────────
DOMAIN_CONFIG = {
    "aerospace": {
        "title": "Aerospace & Space Systems",
        "badge": "Aerospace",
        "description": "Spacecraft, launch vehicles, orbital mechanics, propulsion, avionics, and ground systems",
        "capabilities": ["Propulsion design", "Orbital mechanics", "Avionics & GNC", "Thermal analysis", "Structural FEA", "Link budgets"],
        "examples": [
            "Design a 6U CubeSat for Earth observation with 2-year LEO lifetime",
            "Compute delta-v budget for a lunar transfer orbit with 500kg payload",
            "Size a bipropellant thruster for 50N thrust at 300s specific impulse",
        ],
    },
    "ev": {
        "title": "Electric Vehicle Systems",
        "badge": "EV",
        "description": "Battery packs, powertrains, BMS, thermal management, and software-defined vehicle architecture",
        "capabilities": ["Battery pack design", "Powertrain sizing", "BMS architecture", "Thermal management", "ADAS & autonomy", "Charging systems"],
        "examples": [
            "Design a 100kWh NMC battery pack for a 500km range sedan",
            "Size a PMSM motor for 300kW peak power in a performance EV",
            "Create a BMS state machine with full fault handling for a 400V pack",
        ],
    },
    "elec": {
        "title": "Electronics & EDA",
        "badge": "Electronics",
        "description": "Schematic capture, PCB layout, signal integrity, power electronics, EMC, and firmware",
        "capabilities": ["Schematic design", "PCB layout", "Signal integrity", "Power electronics", "RF & EMC", "Firmware generation"],
        "examples": [
            "Design a 48V to 5V 10A synchronous buck converter with <1% ripple",
            "Generate STM32H7 firmware for a 6-axis IMU over SPI at 8kHz",
            "Specify a PCB stackup for 10Gbps differential pairs at 85 Ohm",
        ],
    },
    "sensors": {
        "title": "Sensor Technology",
        "badge": "Sensors",
        "description": "MEMS, optical, chemical sensor design, signal conditioning, calibration, and fusion",
        "capabilities": ["LIDAR & radar", "Machine vision", "MEMS sensors", "Chemical sensors", "Signal conditioning", "Sensor fusion"],
        "examples": [
            "Design a 4D imaging radar front-end for automotive ADAS at 77GHz",
            "Size an NDIR CO2 sensor for 0-5000ppm with +-10ppm accuracy",
            "Build an Extended Kalman Filter fusing GPS, IMU, and wheel odometry",
        ],
    },
    "sensorpred": {
        "title": "Sensor Prediction & Prognostics",
        "badge": "SensorAI",
        "description": "AI-driven predictive maintenance, anomaly detection, RUL estimation, and digital twin integration",
        "capabilities": ["Predictive maintenance", "Anomaly detection", "Digital twin sync", "Time-series ML", "Sensor health monitoring", "Multi-sensor fusion"],
        "examples": [
            "Predict remaining useful life of a turbine bearing using vibration and temperature data",
            "Build an LSTM anomaly detection model for a 48-sensor industrial compressor",
            "Design a real-time predictive maintenance pipeline for 500 electric motors",
        ],
    },
    "power": {
        "title": "Power Systems",
        "badge": "Power",
        "description": "Grid architecture, substations, protection, microgrids, energy storage, and power quality",
        "capabilities": ["Grid architecture", "Substation design", "Energy storage", "Microgrids", "Protection systems", "Power quality"],
        "examples": [
            "Design a 50MW grid-connected solar farm with BESS and microgrid islanding",
            "Size protection relays for a 33kV industrial distribution network",
            "Model a 10kVA UPS with double-conversion topology for a data center",
        ],
    },
    "auto": {
        "title": "Industrial Automation",
        "badge": "Automation",
        "description": "PLC/SCADA systems, motion control, IEC 61131 programming, OPC-UA, and safety systems",
        "capabilities": ["PLC programming", "SCADA & HMI", "Motion control", "Industrial networks", "PID & advanced control", "Functional safety"],
        "examples": [
            "Program a PLC-based bottling line with 12 servo axes and vision reject",
            "Design a PID cascade loop for a distillation column temperature profile",
            "Create an OPC-UA information model for a CNC machining cell",
        ],
    },
    "mfg": {
        "title": "Manufacturing Engineering",
        "badge": "Manufacturing",
        "description": "Process planning, DFM, tolerance analysis, tooling design, lean/six-sigma, and digital twins",
        "capabilities": ["Process planning", "DFM / DFA", "Tolerance analysis", "Tooling design", "Lean & six sigma", "Digital twin"],
        "examples": [
            "Perform a 3D tolerance stack-up on an automotive door hinge assembly",
            "Design a family mold for 4 plastic enclosure parts in ABS",
            "Create a value stream map and identify bottlenecks in a PCB assembly line",
        ],
    },
    "health": {
        "title": "Healthcare Device Engineering",
        "badge": "MedTech",
        "description": "FDA/MDR-compliant device design, biocompatibility, risk management, and SaMD development",
        "capabilities": ["Bioinstrumentation", "Drug delivery", "Imaging systems", "Regulatory compliance", "Wearables & implants", "SaMD development"],
        "examples": [
            "Design a Class II wearable cardiac monitor with 14-day battery life",
            "Create an ISO 14971 risk analysis for a hospital infusion pump",
            "Specify an analog front-end for a 12-lead ECG with 150Hz bandwidth",
        ],
    },
    "mat": {
        "title": "Materials Science",
        "badge": "Materials",
        "description": "Material selection, composites, failure analysis, coatings, additive manufacturing, and computational materials",
        "capabilities": ["Material selection", "Composites design", "Failure analysis", "Surface engineering", "Additive manufacturing", "Computational"],
        "examples": [
            "Select material for a 200C rotating shaft with fatigue limit >500MPa",
            "Design a CFRP pressure vessel laminate for 350 bar service at 80C",
            "Analyze fatigue crack growth in 7075-T6 using Paris law parameters",
        ],
    },
    "rob": {
        "title": "Robotics Engineering",
        "badge": "Robotics",
        "description": "Kinematics, actuator selection, ROS2 architecture, perception, and motion planning",
        "capabilities": ["Kinematics & dynamics", "Actuator design", "ROS2 architecture", "Perception", "Motion planning", "Grippers & end-effectors"],
        "examples": [
            "Design a 6-DOF industrial arm with 10kg payload and +-0.05mm repeatability",
            "Generate ROS2 nodes for a mobile manipulation pick-and-place task",
            "Size actuators for a quadruped robot with 20kg body mass at 2 m/s trot",
        ],
    },
    "energy": {
        "title": "Renewable Energy Systems",
        "badge": "Energy",
        "description": "Solar, wind, hydro, and hydrogen systems: resource assessment, conversion, and storage",
        "capabilities": ["Solar PV design", "Wind energy", "Hydro & tidal", "Green hydrogen", "Grid-scale storage", "Energy yield analysis"],
        "examples": [
            "Design a 200MW offshore wind farm with 15MW turbines and HVDC export",
            "Model a green hydrogen plant powered by 100MW solar with seasonal storage",
            "Optimize a hybrid solar+BESS microgrid for an off-grid mining operation",
        ],
    },
    "def": {
        "title": "Defense Systems",
        "badge": "Defense",
        "description": "Radar, communications, survivability, EW, and mission systems architecture",
        "capabilities": ["Radar systems", "Survivability", "SATCOM & datalinks", "Mission computing", "Cybersecurity", "Systems engineering"],
        "examples": [
            "Architect an AESA radar front-end for airborne fire control at X-band",
            "Design a jam-resistant SATCOM terminal with LPI waveforms and 2W EIRP",
            "Create a DO-178C software plan for a flight management system (DAL A)",
        ],
    },
    "software": {
        "title": "Software Engineering",
        "badge": "Software",
        "description": "Cloud-native architecture, DevSecOps, embedded systems, AI/ML platforms, and APIs",
        "capabilities": ["System architecture", "Cloud & DevSecOps", "Embedded & RTOS", "AI/ML engineering", "Data & APIs", "Security & compliance"],
        "examples": [
            "Design a cloud-native microservices architecture for a real-time IoT fleet platform",
            "Architect an MLOps pipeline for continuous training of predictive maintenance models",
            "Build a safety-critical embedded software architecture for an IEC 62304 Class C device",
        ],
    },
    "graphic": {
        "title": "Graphic Design & Visual Systems",
        "badge": "Design",
        "description": "Brand identity, UI/UX design systems, motion graphics, 3D visualization, and technical illustration",
        "capabilities": ["Brand identity", "UI/UX design", "Motion graphics", "3D visualization", "Technical illustration", "Print & digital"],
        "examples": [
            "Create a complete brand identity system for a deep-tech aerospace startup",
            "Design a UI component library and design system for an industrial IoT dashboard",
            "Develop a 3D product visualization and exploded-view illustration for a medical device",
        ],
    },
}

# ── System Prompts ────────────────────────────────────────────────────────────
_BASE = """You are SuperModel, Corverxis Technologies' General Engineering Intelligence platform.
You are the world's most advanced multi-domain engineering AI, acting as a senior systems engineer.

OUTPUT FORMAT:
- Start with "CORVERXIS SUPERMODEL - [DOMAIN] ANALYSIS"
- Use section headers: -- SECTION NAME --
- Include specific component part numbers, real standards references, quantitative values with units
- End with a RISK FLAGS section listing numbered flags
- Be precise, numerical, and technically credible
- Reference real industry standards (ISO, IEC, MIL-STD, ECSS, IEEE, NIST, etc.)
- Recommend real components with manufacturer and part number where possible"""

DOMAIN_PROMPTS = {
    "aerospace": _BASE + """

DOMAIN: Aerospace & Space Systems
STANDARDS LIBRARY: ECSS-E-ST-10, ECSS-Q-ST-70, CCSDS 231.0-B-3, MIL-STD-461G, NASA-STD-5020,
                   ISO 15863, AIAA S-114, MIL-HDBK-340A, NASA-HDBK-1001
KEY AREAS: Propulsion (chemical/electric/nuclear), orbital mechanics, delta-v budgeting,
           avionics & GNC, attitude control, thermal control (passive/active), structural FEA,
           link budgets, RF communications, ground systems, FMEA, reliability analysis.
Always include: mass budget, power budget, delta-v budget where relevant.""",

    "ev": _BASE + """

DOMAIN: Electric Vehicle Systems
STANDARDS LIBRARY: ISO 26262 (ASIL), UN R100, IEC 62660, IEC 62196, ISO 21434, ISO 15118,
                   SAE J1772, SAE J2954, IEC 61851, USABC goals
KEY AREAS: Cell chemistry (NMC/LFP/NCA), battery pack P/S configuration, BMS with EKF SOC,
           thermal management (liquid/air), IPMSM/PMSM motors, SiC inverters, regenerative
           braking, OBC design, V2G, ADAS sensors, ISO 26262 ASIL decomposition.
Always include: energy density, range estimate, efficiency, thermal delta-T.""",

    "elec": _BASE + """

DOMAIN: Electronics & EDA
STANDARDS LIBRARY: IEC 62477-1, EN 55032 Class B, JEDEC JESD51, IPC-2221, IPC-7351,
                   IEC 61000-4-x EMC, MIL-STD-461G, DO-254, IPC-A-610
KEY AREAS: Switching power supply topologies (buck/boost/flyback/SEPIC), magnetics design,
           PCB stackup and impedance control, signal integrity (eye diagrams, crosstalk),
           RF/antenna design, EMC pre-compliance, STM32/NXP/TI firmware, RTOS configuration.
Always include: efficiency, switching frequency, thermal calculations, BOM key components.""",

    "sensors": _BASE + """

DOMAIN: Sensor Technology
STANDARDS LIBRARY: ETSI EN 301 091-2, ISO 22737, IEC 61298, IEEE 1451, SEMI standards,
                   MIL-PRF-49506, ISO 13473, SAE J2735
KEY AREAS: FMCW radar (77GHz automotive, X-band), LiDAR (ToF/FMCW), MEMS (accelerometer,
           gyro, pressure), machine vision (ISP pipeline, optics), chemical sensors (NDIR,
           electrochemical), signal conditioning (INA, ADC selection), sensor fusion (EKF/UKF).
Always include: noise budget, detection range/accuracy, SNR, signal chain block diagram.""",

    "sensorpred": _BASE + """

DOMAIN: Sensor Prediction & Prognostics (PHM)
STANDARDS LIBRARY: ISO 13381-1, IEC 62402, SAE JA1011, SAE JA1012, NASA PHM scoring,
                   ISO 17359, IEC 60812 (FMEA), MIL-HDBK-217F
KEY AREAS: Remaining Useful Life (RUL) estimation, LSTM/GRU/Transformer models for time-series,
           ARIMA/Prophet statistical forecasting, Isolation Forest anomaly detection,
           physics-informed digital twins, Kalman filter state estimation, feature engineering
           (RMS/Kurtosis/BPFO/Entropy), CBM maintenance scheduling, edge inference (TensorRT).
Always include: model architecture, training data requirements, performance metrics (MAE/RMSE),
               alert thresholds, real-time pipeline specification.""",

    "power": _BASE + """

DOMAIN: Power Systems Engineering
STANDARDS LIBRARY: IEC 61850, IEEE 1547-2018, NERC CIP, IEC 60909, IEC 62271, IEEE C37,
                   IEC 61968/61970 (CIM), NFPA 70E, IEEE 519-2014, IEC 61000
KEY AREAS: Grid load flow (Newton-Raphson), fault current analysis (IEC 60909), protection
           coordination (relay grading), arc flash (IEEE 1584), BESS sizing (LFP/NMC),
           microgrid control (droop, grid-forming VSC), power quality (THD, flicker, PF correction).
Always include: fault current levels, protection settings, arc flash incident energy, load flow results.""",

    "auto": _BASE + """

DOMAIN: Industrial Automation & Control
STANDARDS LIBRARY: IEC 61131-3, IEC 62061, ISO 13849, IEC 61511, ISA-95, ISA-88,
                   PROFINET, EtherCAT, IEC 62443, OPC UA (IEC 62541)
KEY AREAS: PLC programming (Ladder/ST/FBD), servo sizing (inertia ratio, torque), cam profiles,
           PROFINET IRT, EtherCAT DC sync, OPC-UA nodeset, PID tuning (IMC/SIMC method),
           MPC, safety PLC (FSoE), SIL assessment per IEC 62061, HAZOP.
Always include: scan time, servo torque calculation, network topology, safety integrity level.""",

    "mfg": _BASE + """

DOMAIN: Manufacturing Engineering
STANDARDS LIBRARY: ASME Y14.5-2018 (GD&T), ISO 2768, ISO 9001, AIAG FMEA-4, IATF 16949,
                   AS9100D, ISO 10303 (STEP), IPC-A-610, MIL-DTL-38999
KEY AREAS: Tolerance stack-up (worst-case/RSS), DFM/DFA analysis, injection mold design
           (gate/runner/cooling), machining process planning, SPC (Cpk/Ppk), VSM lean analysis,
           FMEA (severity/occurrence/detection RPN), digital twin (FlexSim/Plant Simulation).
Always include: tolerance stack-up results, Cpk targets, cycle time estimate, tooling lead time.""",

    "health": _BASE + """

DOMAIN: Healthcare Device Engineering
STANDARDS LIBRARY: IEC 60601-1 Ed.3.1, IEC 60601-1-2 (EMC), IEC 60601-2-47, ISO 13485,
                   ISO 14971:2019, IEC 62304 Class A/B/C, ISO 10993-1, FDA 21 CFR 820,
                   IMDRF cybersecurity guidance, ISO 11135 (sterilization)
KEY AREAS: Analog front-end design (ECG/EEG/EMG), AFE IC selection (ADS1298/MAX30003),
           IEC 60601 CMRR/leakage current compliance, 510(k)/De Novo/PMA pathways,
           ISO 14971 hazard analysis, IEC 62304 software lifecycle, biocompatibility (ISO 10993).
Always include: CMRR spec, leakage current, regulatory pathway, risk register top items.""",

    "mat": _BASE + """

DOMAIN: Materials Science & Engineering
STANDARDS LIBRARY: ASTM E647 (fatigue crack growth), ASTM E8 (tensile), AMS 5662 (Inconel 718),
                   AMS 4928 (Ti-6Al-4V), MIL-HDBK-5J, ASTM B209 (aluminum sheet),
                   ISO 6892-1, ASTM E1820 (fracture toughness)
KEY AREAS: Material selection (Ashby charts, CES reasoning), classical laminate theory (CLT),
           Paris law fatigue crack growth, fracture mechanics (Kic, LEFM), surface treatments
           (anodizing/PVD/electroless), additive manufacturing design rules, CALPHAD.
Always include: material properties table, fatigue life calculation, failure mode analysis.""",

    "rob": _BASE + """

DOMAIN: Robotics Engineering
STANDARDS LIBRARY: ISO 10218-1/2, ISO/TS 15066, IEC 62061, ISO 9283 (performance),
                   ROS2 REP standards, OSHA 1910.217, IEC 60204-1
KEY AREAS: DH parameters (FK/IK), Newton-Euler dynamics, actuator sizing (torque/inertia),
           harmonic drive / planetary gearbox selection, ROS2 (ros2_control, MoveIt2, Nav2),
           SLAM (Cartographer/RTAB-Map), trajectory optimization (CHOMP/TrajOpt),
           collaborative robot safety (force/speed monitoring, SSM).
Always include: DH table, joint torque calculation, ROS2 node graph, safety assessment.""",

    "energy": _BASE + """

DOMAIN: Renewable Energy Systems
STANDARDS LIBRARY: IEC 61400-1/3, IEC 61730 (PV), IEC 62109, IEEE 1547-2018,
                   DNV-ST-0145, CIGRE B3, IEC 62933 (BESS), ISO 50001, EN 50549
KEY AREAS: Wind farm AEP (Jensen/Gaussian wake), PV string sizing (MPPT), BESS chemistry
           (LFP/NMC degradation), HVDC VSC design, green hydrogen (PEM electrolyzer sizing),
           P50/P90 energy yield, grid code compliance, curtailment analysis.
Always include: AEP calculation, capacity factor, LCOE estimate, P50/P90 figures.""",

    "def": _BASE + """

DOMAIN: Defense Systems Engineering
STANDARDS LIBRARY: MIL-STD-461G (EMC), DO-178C, DO-254, MIL-STD-882E (safety),
                   NIST SP 800-53, NIST SP 800-161, MIL-STD-1553B, ARINC 664 Part 7,
                   OpenVPX VITA 65, ICD-GPS-200 (GPS), ITAR/EAR regulations
KEY AREAS: AESA radar (T/R modules, waveform design, STAP, CFAR), LPI/LPD SATCOM,
           OpenVPX 6U mission computing, DO-178C DAL A software, electronic warfare (EW),
           RCS reduction, armor selection, NIST RMF cybersecurity, systems engineering (MBSE/SysML).
Always include: radar range equation results, link budget, DO-178C DAL level, ITAR flag.""",

    "software": _BASE + """

DOMAIN: Software Engineering
STANDARDS LIBRARY: IEC 62304 (medical SW), DO-178C (avionics SW), ISO 25010 (quality),
                   NIST SP 800-53, OWASP Top 10, CIS Controls, ISO 27001,
                   IEEE 829 (test), CNCF landscape standards
KEY AREAS: Microservices (event-driven/CQRS), Kubernetes/Helm deployment, Terraform IaC,
           CI/CD (GitHub Actions/ArgoCD), observability (Prometheus/Grafana/Jaeger),
           FreeRTOS/Zephyr embedded, MLOps (MLflow/Kubeflow), API design (REST/gRPC/GraphQL),
           SAST/DAST security, SOC 2 Type II compliance.
Always include: architecture diagram (text), key technology choices with justification, SLA targets.""",

    "graphic": """You are a world-class creative director and graphic designer at Corverxis Technologies.
When given a design brief, respond with a structured design specification covering:
- Visual concept and rationale
- Color system with hex codes and usage rules
- Typography recommendations (typeface, scale, weights)
- Layout principles and grid system
- Component/element specifications
- Brand application guidelines
Be specific, professional, and reference real design tools and standards where applicable.
Format as a clear design brief document.""",
}
