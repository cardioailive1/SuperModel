"""
Design router — generates graphic design output using Claude.
Returns SVG/HTML design artifacts rendered client-side.
"""

from fastapi import APIRouter, Request, HTTPException
from pydantic import BaseModel

router = APIRouter()


class DesignRequest(BaseModel):
    prompt: str
    style: str = "brand"  # brand | ui | infographic | poster | typography


DESIGN_SYSTEM_PROMPT = """You are a world-class graphic designer and creative director at Corverxis Technologies.
Generate stunning, production-quality graphic design using pure SVG and HTML/CSS.

RULES:
- Output ONLY raw SVG or HTML+CSS — no markdown, no backticks, no explanation
- Use SVG for logos, icons, illustrations, and visual elements
- Use inline CSS for typography and layout
- All content must be self-contained (no external resources except Google Fonts via @import)
- Primary palette: Navy #0e2444, Ocean Blue #00c2e0, White #ffffff, Light #e2f4f9
- Make designs bold, modern, and professional
- Include real design content — actual logos, color swatches, type specimens, UI components
- Output must render correctly when injected into a white div container"""


@router.post("/design/generate")
async def generate_design(req: DesignRequest, request: Request):
    """Generate graphic design output via Claude."""
    client = request.app.state.anthropic

    try:
        message = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=4096,
            system=DESIGN_SYSTEM_PROMPT,
            messages=[
                {
                    "role": "user",
                    "content": f"Design style: {req.style}\n\nRequest: {req.prompt}",
                }
            ],
        )
        raw = message.content[0].text.strip()
        # Strip any accidental markdown fences
        raw = raw.replace("```html", "").replace("```svg", "").replace("```", "").strip()
        return {"design": raw, "style": req.style}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
