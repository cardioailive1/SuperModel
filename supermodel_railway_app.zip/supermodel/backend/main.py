"""
SuperModel Backend — Corverxis Technologies
FastAPI server handling Claude AI inference, auth, and data persistence.
"""

import os
import time
import uuid
from contextlib import asynccontextmanager
from typing import Optional

import anthropic
from fastapi import FastAPI, HTTPException, Request, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, JSONResponse
from pydantic import BaseModel

from routers import analyze, health, history, design

# ── Startup / Shutdown ────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    print("SuperModel API starting up...")
    app.state.anthropic = anthropic.Anthropic(
        api_key=os.environ.get("ANTHROPIC_API_KEY")
    )
    yield
    print("SuperModel API shutting down...")

# ── App ───────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="SuperModel API",
    description="Corverxis Technologies General Engineering Intelligence Platform",
    version="1.0.0",
    lifespan=lifespan,
)

# ── CORS ──────────────────────────────────────────────────────────────────────
origins = os.environ.get("CORS_ORIGINS", "http://localhost:3000").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins + ["http://localhost:3000", "http://localhost:3001"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Request logging middleware ────────────────────────────────────────────────
@app.middleware("http")
async def log_requests(request: Request, call_next):
    start = time.time()
    response = await call_next(request)
    duration = round((time.time() - start) * 1000)
    print(f"{request.method} {request.url.path} -> {response.status_code} ({duration}ms)")
    return response

# ── Routers ───────────────────────────────────────────────────────────────────
app.include_router(health.router, tags=["Health"])
app.include_router(analyze.router, prefix="/api", tags=["Analysis"])
app.include_router(history.router, prefix="/api", tags=["History"])
app.include_router(design.router, prefix="/api", tags=["Design"])

# ── Root ──────────────────────────────────────────────────────────────────────
@app.get("/")
async def root():
    return {
        "product": "SuperModel",
        "company": "Corverxis Technologies",
        "version": "1.0.0",
        "status": "online",
        "domains": 15,
    }
