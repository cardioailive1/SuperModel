import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'SuperModel — Corverxis Technologies',
  description: 'General Engineering Intelligence Platform. Design, simulate and validate complex physical systems across 15 engineering domains.',
  icons: { icon: '/favicon.svg' },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-navy-800 text-navy-50 antialiased">
        {children}
      </body>
    </html>
  )
}
