# Railway Deployment Guide — SuperModel

## Step 1: Push to GitHub

```bash
git init
git add .
git commit -m "Initial SuperModel production app"
git remote add origin https://github.com/YOUR_ORG/supermodel.git
git push -u origin main
```

## Step 2: Create Railway Project

1. Go to https://railway.app
2. Click "New Project"
3. Select "Deploy from GitHub repo"
4. Select your supermodel repository
5. Railway will detect the railway.toml and create 2 services automatically

## Step 3: Add PostgreSQL and Redis

In Railway dashboard:
1. Click "+ New" -> "Database" -> "PostgreSQL"
2. Click "+ New" -> "Database" -> "Redis"
Railway auto-injects DATABASE_URL and REDIS_URL into your services.

## Step 4: Set Environment Variables

### Backend service variables:
```
ANTHROPIC_API_KEY    = sk-ant-xxxxxxxxxxxxxxxx
CORS_ORIGINS         = https://YOUR-FRONTEND.railway.app
SECRET_KEY           = (generate with: python -c "import secrets; print(secrets.token_hex(32))")
```

### Frontend service variables:
```
NEXT_PUBLIC_API_URL  = https://YOUR-BACKEND.railway.app
```

## Step 5: Deploy

Railway auto-deploys on every git push.
- Backend: uvicorn FastAPI server on detected PORT
- Frontend: Next.js standalone build

## Step 6: Get your URLs

Railway provides:
- Frontend: https://supermodel-frontend-XXXX.railway.app
- Backend:  https://supermodel-backend-XXXX.railway.app

Set a custom domain in Railway settings if desired:
- app.supermodel.ai -> frontend service
- api.supermodel.ai -> backend service

## Costs on Railway

| Resource | Cost |
|---|---|
| Backend (FastAPI) | ~$5-10/month |
| Frontend (Next.js) | ~$5-10/month |
| PostgreSQL | ~$5/month |
| Redis | ~$5/month |
| **Total** | **~$20-30/month** |

Anthropic API costs extra depending on usage (~$0.003 per analysis).

## Local Development

```bash
# Terminal 1 - Backend
cd backend
pip install -r requirements.txt
cp .env.example .env
# Edit .env with your ANTHROPIC_API_KEY
uvicorn main:app --reload --port 8000

# Terminal 2 - Frontend
cd frontend
npm install
cp .env.example .env.local
# Edit .env.local: NEXT_PUBLIC_API_URL=http://localhost:8000
npm run dev
```

Visit http://localhost:3000

## Architecture on Railway

```
Internet
    |
    v
[Railway Load Balancer]
    |           |
    v           v
[Frontend]  [Backend]
Next.js     FastAPI
Port 3000   Port 8000
    |           |
    v           v
         [PostgreSQL]
         [Redis Cache]
         [Anthropic API]
```
