"""
History router — saves and retrieves analysis sessions.
Uses in-memory store for now; swap DATABASE_URL for PostgreSQL in production.
"""

import uuid
from datetime import datetime
from typing import Optional
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter()

# In-memory store (replace with PostgreSQL via asyncpg in production)
_sessions: dict = {}


class SaveRequest(BaseModel):
    domain: str
    prompt: str
    response: str
    session_id: Optional[str] = None


@router.post("/history/save")
async def save_analysis(req: SaveRequest):
    """Save an analysis to history."""
    session_id = req.session_id or str(uuid.uuid4())
    _sessions[session_id] = {
        "id": session_id,
        "domain": req.domain,
        "prompt": req.prompt,
        "response": req.response,
        "created_at": datetime.utcnow().isoformat(),
    }
    return {"session_id": session_id, "saved": True}


@router.get("/history")
async def get_history(limit: int = 20):
    """Get recent analysis history."""
    items = sorted(
        _sessions.values(),
        key=lambda x: x["created_at"],
        reverse=True,
    )[:limit]
    return {"history": items, "total": len(_sessions)}


@router.get("/history/{session_id}")
async def get_session(session_id: str):
    """Get a specific analysis session."""
    if session_id not in _sessions:
        raise HTTPException(status_code=404, detail="Session not found")
    return _sessions[session_id]


@router.delete("/history/{session_id}")
async def delete_session(session_id: str):
    """Delete an analysis session."""
    if session_id not in _sessions:
        raise HTTPException(status_code=404, detail="Session not found")
    del _sessions[session_id]
    return {"deleted": True}
