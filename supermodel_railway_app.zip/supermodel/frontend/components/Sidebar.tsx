'use client'

import { DOMAINS, DOMAIN_KEYS, type DomainKey } from '@/lib/domains'

const ICONS: Record<DomainKey, string> = {
  aerospace: 'M12 2L8 8H4l2 4-2 2h4l4 8 4-8h4l-2-2 2-4h-4L12 2z',
  ev: 'M0 0', // handled inline
  elec: 'M0 0',
  sensors: 'M0 0',
  sensorpred: 'M0 0',
  power: 'M13 2L3 14h9l-1 8 10-12h-9l1-8z',
  auto: 'M0 0',
  mfg: 'M3 21h18M3 7l9-4 9 4M5 21V7m14 14V7M10 21v-4h4v4',
  health: 'M3 12h4l3-8 4 16 3-8h4',
  mat: 'M0 0',
  rob: 'M0 0',
  energy: 'M0 0',
  def: 'M12 3l8 4v5c0 5-3.5 9-8 10C7.5 21 4 17 4 12V7l8-4z',
  software: 'M0 0',
  graphic: 'M0 0',
}

function DomainIcon({ domain }: { domain: DomainKey }) {
  const icons: Record<DomainKey, JSX.Element> = {
    aerospace: <><path d="M12 2L8 8H4l2 4-2 2h4l4 8 4-8h4l-2-2 2-4h-4L12 2z"/></>,
    ev: <><rect x="2" y="8" width="20" height="10" rx="3"/><path d="M6 8V6a2 2 0 012-2h8a2 2 0 012 2v2"/><path d="M7 14h2m4 0h2"/></>,
    elec: <><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 9h1m5 0h1M9 15h1m5 0h1M7 12h10"/></>,
    sensors: <><circle cx="12" cy="12" r="3"/><path d="M6.3 6.3a8 8 0 000 11.4M17.7 6.3a8 8 0 010 11.4M3.5 3.5a13 13 0 000 17M20.5 3.5a13 13 0 010 17"/></>,
    sensorpred: <><path d="M2 12h2l3-8 4 16 3-8 2 4 2-8 2 4h2"/><circle cx="20" cy="12" r="2" fill="currentColor"/></>,
    power: <><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></>,
    auto: <><rect x="3" y="11" width="5" height="9" rx="1"/><rect x="9.5" y="7" width="5" height="13" rx="1"/><rect x="16" y="4" width="5" height="16" rx="1"/></>,
    mfg: <><path d="M3 21h18M3 7l9-4 9 4"/><path d="M5 21V7m14 14V7M10 21v-4h4v4"/></>,
    health: <><path d="M3 12h4l3-8 4 16 3-8h4"/></>,
    mat: <><circle cx="12" cy="12" r="1"/><path d="M12 2a10 10 0 100 20A10 10 0 0012 2z"/><path d="M12 2v20M2 12h20"/></>,
    rob: <><rect x="7" y="10" width="10" height="10" rx="1"/><path d="M9 10V7a3 3 0 016 0v3"/><circle cx="9.5" cy="15" r="1" fill="currentColor"/><circle cx="14.5" cy="15" r="1" fill="currentColor"/></>,
    energy: <><path d="M12 3v1m0 16v1m9-9h-1M4 12H3"/><circle cx="12" cy="12" r="4"/><path d="M18.4 5.6l-.7.7M6.3 17.7l-.7.7M18.4 18.4l-.7-.7M6.3 6.3l-.7-.7"/></>,
    def: <><path d="M12 3l8 4v5c0 5-3.5 9-8 10C7.5 21 4 17 4 12V7l8-4z"/></>,
    software: <><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></>,
    graphic: <><circle cx="12" cy="12" r="3"/><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10"/><path d="M12 8v1m0 6v1M8 12h1m6 0h1"/></>,
  }
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="w-3.5 h-3.5 flex-shrink-0">
      {icons[domain]}
    </svg>
  )
}

interface SidebarProps {
  activeDomain: DomainKey
  onDomainChange: (key: DomainKey) => void
}

export default function Sidebar({ activeDomain, onDomainChange }: SidebarProps) {
  return (
    <aside className="w-[220px] flex-shrink-0 bg-navy-900 border-r border-ocean-400/12 overflow-y-auto">
      <div className="p-4 pb-2">
        <div className="text-[9px] font-mono font-medium text-navy-400 tracking-[2px] uppercase mb-3">
          Engineering Domains
        </div>
        <nav className="flex flex-col gap-0.5">
          {DOMAIN_KEYS.map(key => {
            const domain = DOMAINS[key]
            const isActive = key === activeDomain
            return (
              <button
                key={key}
                onClick={() => onDomainChange(key)}
                className={`flex items-center gap-2.5 w-full px-3 py-2 rounded-lg text-left text-[12.5px] transition-all duration-100 border-l-2 ${
                  isActive
                    ? 'bg-ocean-400/10 border-ocean-400 text-ocean-300 font-medium'
                    : 'border-transparent text-navy-300 hover:bg-ocean-400/5 hover:text-white'
                }`}
              >
                <DomainIcon domain={key} />
                <span className="truncate">{domain.title}</span>
              </button>
            )
          })}
        </nav>
      </div>

      {/* Version tag */}
      <div className="p-4 pt-2 mt-auto">
        <div className="text-[9px] font-mono text-navy-500 text-center">
          SuperModel v1.0 — Corverxis
        </div>
      </div>
    </aside>
  )
}
