'use client'

export default function Header() {
  return (
    <header className="flex-shrink-0 bg-navy-900 border-b border-ocean-400/20 z-10">
      <div className="flex items-center justify-between h-16 px-6">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <svg width="36" height="36" viewBox="0 0 80 80" className="flex-shrink-0">
            <polygon points="40,8 68,24 68,56 40,72 12,56 12,24" fill="none" stroke="#00c2e0" strokeWidth="2.5"/>
            <polygon points="40,20 58,30 58,50 40,60 22,50 22,30" fill="none" stroke="#00c2e0" strokeWidth="1.5" opacity="0.5"/>
            <circle cx="40" cy="40" r="6" fill="#00c2e0"/>
            <circle cx="40" cy="8"  r="3" fill="#00c2e0"/>
            <circle cx="68" cy="24" r="3" fill="#00c2e0"/>
            <circle cx="68" cy="56" r="3" fill="#00c2e0"/>
            <circle cx="40" cy="72" r="3" fill="#00c2e0"/>
            <circle cx="12" cy="56" r="3" fill="#00c2e0"/>
            <circle cx="12" cy="24" r="3" fill="#00c2e0"/>
          </svg>
          <div className="w-px h-8 bg-ocean-400/25"/>
          <div>
            <div className="text-base font-bold text-white tracking-wide">SuperModel</div>
            <div className="text-[9px] font-medium text-ocean-400 tracking-[3px] uppercase font-mono">
              Corverxis Technologies
            </div>
          </div>
        </div>

        {/* Status */}
        <div className="flex items-center gap-5 text-xs font-mono text-navy-300">
          <div className="flex items-center gap-2 text-emerald-400">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-[0_0_8px_#34d399] animate-pulse-slow"/>
            Systems online
          </div>
          <span className="text-navy-400">15 domains</span>
          <span className="text-navy-400">63 expert models</span>
          <span className="text-navy-400 hidden md:block">Physics + CAD + EDA + BIO</span>
        </div>
      </div>

      {/* Ticker */}
      <div className="bg-navy-950 border-t border-ocean-400/10 overflow-hidden py-1">
        <div className="flex animate-[ticker_35s_linear_infinite] whitespace-nowrap">
          {[
            'SUPERMODEL v1.0 ONLINE',
            '15 ENGINEERING DOMAINS',
            'AEROSPACE: DELTA-V SYNTHESIS READY',
            'EV: BATTERY OPTIMIZER ACTIVE',
            'SENSOR PREDICTION: LSTM MODEL WARM',
            'MEDTECH: ISO 14971 RISK ENGINE READY',
            'CORVERXIS TECHNOLOGIES - AI ENGINEERING & CONSULTING',
          ].map((t, i) => (
            <span key={i} className="text-[10px] font-mono text-navy-400 mx-8">
              {t}
              <span className="mx-8 text-ocean-400/30">|</span>
            </span>
          ))}
        </div>
      </div>
    </header>
  )
}
