'use client'

import { useState, useCallback } from 'react'
import Header from '@/components/Header'
import Sidebar from '@/components/Sidebar'
import AnalysisPanel from '@/components/AnalysisPanel'
import ChatAssistant from '@/components/ChatAssistant'
import { DOMAINS, type DomainKey } from '@/lib/domains'

export default function Home() {
  const [activeDomain, setActiveDomain] = useState<DomainKey>('aerospace')
  const [prompt, setPrompt] = useState('')
  const [modes, setModes] = useState<string[]>(['Design'])
  const [output, setOutput] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [isStreaming, setIsStreaming] = useState(false)
  const [metrics, setMetrics] = useState<{[k:string]:string} | null>(null)

  const handleDomainChange = useCallback((key: DomainKey) => {
    setActiveDomain(key)
    setOutput('')
    setMetrics(null)
    setPrompt('')
  }, [])

  const handleRun = useCallback(async () => {
    if (!prompt.trim()) return
    setIsLoading(true)
    setIsStreaming(true)
    setOutput('')
    setMetrics(null)

    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000'

    try {
      const response = await fetch(`${apiUrl}/api/analyze/stream`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ domain: activeDomain, prompt, modes }),
      })

      if (!response.ok) throw new Error(`API error: ${response.status}`)

      const reader = response.body?.getReader()
      const decoder = new TextDecoder()
      let fullText = ''

      while (reader) {
        const { done, value } = await reader.read()
        if (done) break
        const chunk = decoder.decode(value)
        const lines = chunk.split('\n').filter(l => l.startsWith('data: '))
        for (const line of lines) {
          try {
            const data = JSON.parse(line.slice(6))
            if (data.text) { fullText += data.text; setOutput(fullText) }
            if (data.done) {
              setIsStreaming(false)
              const d = DOMAINS[activeDomain]
              setMetrics({ subsystems: d.metrics[0], standards: d.metrics[1], simIters: d.metrics[2], riskFlags: d.metrics[3] })
            }
            if (data.error) throw new Error(data.error)
          } catch {}
        }
      }
    } catch (err: any) {
      setOutput(`Error: ${err.message}\n\nMake sure the backend is running and NEXT_PUBLIC_API_URL is set correctly.`)
      setIsStreaming(false)
    } finally {
      setIsLoading(false)
    }
  }, [activeDomain, prompt, modes])

  const handleExampleClick = useCallback((example: string) => {
    setPrompt(example)
  }, [])

  const toggleMode = useCallback((mode: string) => {
    setModes(prev => prev.includes(mode) ? prev.filter(m => m !== mode) : [...prev, mode])
  }, [])

  return (
    <div className="flex flex-col h-screen overflow-hidden grid-bg">
      <Header />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar
          activeDomain={activeDomain}
          onDomainChange={handleDomainChange}
        />
        <AnalysisPanel
          domain={activeDomain}
          prompt={prompt}
          onPromptChange={setPrompt}
          modes={modes}
          onModeToggle={toggleMode}
          output={output}
          isLoading={isLoading}
          isStreaming={isStreaming}
          metrics={metrics}
          onRun={handleRun}
          onExampleClick={handleExampleClick}
        />
      </div>
      <ChatAssistant activeDomain={activeDomain} />
    </div>
  )
}
